Median
======

Basic median cut color quantization.
