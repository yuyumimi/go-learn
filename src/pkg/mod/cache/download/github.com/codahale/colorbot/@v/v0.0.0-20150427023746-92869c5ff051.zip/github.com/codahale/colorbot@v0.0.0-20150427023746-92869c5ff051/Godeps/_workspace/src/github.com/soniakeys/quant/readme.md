Quant
=====

Experiments with color quantizers

Implemented here are two rather simple quantizers and an (also simple) ditherer.
The quantizers satisfy the draw.Quantizer interface of the standard library.
The ditherer satisfies the draw.Drawer interface of the standard library.
